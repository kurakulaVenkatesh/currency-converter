import React from 'react';

const CurrencyDropdown = ({ currencies, selectedCurrency, onChangeCurrency }) => {
  return (
    <select
      value={selectedCurrency}
      onChange={(e) => onChangeCurrency(e.target.value)}
      className="form-control"
    >
       <option value="" disabled>
        Select Currency
      </option>
      {currencies.map((currency) => (
        <option key={currency} value={currency}>
          {currency}
        </option>
      ))}
    </select>
  );
};

export default CurrencyDropdown;
